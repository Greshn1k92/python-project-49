### Hexlet tests and linter status:
[![Actions Status](https://github.com/Greshn1k92/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Greshn1k92/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/1d038394b23f89a265ce/maintainability)](https://codeclimate.com/github/Greshn1k92/python-project-49/maintainability)

https://asciinema.org/a/bjQMG4mhPx0oCaF2xC4XmJHid

https://asciinema.org/a/0wKXK8PP8MDQVZMj50B77CxBh
